/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libreria;

import java.awt.AWTException;
import java.awt.Robot;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import libreria.persistencia.AutorDAO;
import libreria.persistencia.EditorialDAO;
import libreria.persistencia.LibroDAO;
import libreria.servicios.AutorService;
import libreria.servicios.EditorialService;
import libreria.servicios.LibroService;
import java.util.Scanner;
/**
 *
 * @author LEOPOLDO
 */
public class Libreria {

    /**
     * @param args the command line arguments
     * @throws java.lang.Exception
     */
    public static void main(String[] args) throws Exception {
        Scanner leer = new Scanner(System.in).useDelimiter("\n");
        
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("LibreriaPU");
        EntityManager em = emf.createEntityManager();
       
        AutorService au = new AutorService();
        AutorDAO ad = new AutorDAO();
        EditorialDAO ed = new EditorialDAO();
        EditorialService es = new EditorialService();
        LibroService ls = new LibroService();
        LibroDAO ld = new LibroDAO();
        
        int opcion;
        do {
      
        System.out.println("-------Menu------");
        System.out.println("Que opción elige?");
        System.out.println(" ");
        System.out.println("1 - Ingresar un libro");
        System.out.println("2 - Eliminar un libro");
        System.out.println("3 - Ver todos los libros");
        System.out.println("4 - Ver todos los autores");
        System.out.println("5 - Salir del sistema");
        
        opcion = leer.nextInt();
        switch (opcion) {
            case 1:
                System.out.println("Ingrese título, autor y editorial del libro que quiere ingresar");
                String titulo = leer.next();
                String autor = leer.next();
                String editorial = leer.next();
                ls.creaLibro(titulo, autor, editorial);
                break;
            case 2:
                System.out.println("Ingrese el título del libro que desea eliminar");
                String borrar = leer.next();
                ls.eliminarLibro(borrar);
                break;
            case 3:
                System.out.println("Estos son todos los libros de la biblioteca");
                System.out.println(" ");
               ld.listarLibros();
                break;
            case 4:
                System.out.println("Estos son todos los autores de la biblioteca");
                System.out.println(" ");
                ad.listarAutors();
                break;
            case 5:
                System.out.println("Gracias por consultarnos");
                break;
             } 
      au.limpiarPantalla();
        }while (opcion != 5);
        
    
 
        
        // Alternativa pidiendo al usuario el nombre
//        System.out.println("Ingrese autor");
//        String aux = leer.next();
//        System.out.println(aux);
         //  au.creaAutor("Borges");
     
        
       //  au.eliminarAutor(aux);  
     //  au.modificarAutor("juam", "Isabel Allende");    
     //  System.out.println(ad.listarAutors()); // Funciona solo si NO es void el método
      // System.out.println(ad.buscarAutorPorNombre("Funes"));
     //  System.out.println(ed.listarEditorials());
  //   ad.listarAutors();
        
        
       //  es.creaEditorial("New Sheffields");
       
       // CREAR LIBRO CON TITULO, AUTOR, EDITORIAL
     // ls.creaLibro("Como programar y no morir en el intento 2" , "Adriana Bellisteiro" , "Programacion 2000");  
      //  System.out.println("");
     //   System.out.println(ld.listarLibros()); // Funciona solo si NO es void el método
      //  ld.listarLibros();
    
     //  ls.creaLibro("El mago de Oz"); // solo con el titulo
        
      //  es.eliminarEditorial("El_Ateneo");
   //   ls.eliminarLibro("Las mil y una noches2");
    
     // es.modificarEditorial("El Ateneo", "Yenny");
    

      
        // TODO code application logic here
        
    }
    
}
